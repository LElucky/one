<form class="am-form" id="form" method="get">
  <div class="admin-content">

    <div class="am-cf am-padding">
      <div class="am-fl am-cf"><strong class="am-text-primary am-text-lg"><a href="{{url('admin/question/oper')}}">问答</a></strong> /
		
       <small>Table</small></div>
    </div>