<?php echo $__env->make('index/layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class='container'>
			<div id="comment_div"
				class="t-10 label-div border-all pr-20 pt-50 pl-20" >
				<!-- 评论箱  -->
				<a href="<?php echo e(url('index/question/container/' . $replay[0]['question_id'])); ?>">返回上一级</a>

					<div class="comment_box_comment" id="comment-box">
						
						<div class="comments-info clearfix">
							<div class="comments-tab left">
								<a href="javascript:void(0);"><span class="rows_count"></span>
									条回复</a>
							</div>

						</div>
						<?php $__currentLoopData = $replay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<ul class="comments-list clearfix">
							<li class="cleaarfix p1">
								<div class="left post-img">
									<a target="_blank" href="javascript:;" title="标题标题"><img
										src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($r->getReplayUserInfo->user_image); ?>" alt="标题标题"></a>
								</div>
								<div class="post-info">
									<div style="line-height: 16px; margin-bottom: 9px;">
										<a class="fs14 r-10" target="_blank" href="/u/16999.html" title="jack_radio">
											<?php if($r->getReplayUserInfo->nick_name != ''): ?> <?php echo e($r->getReplayUserInfo->nick_name); ?> <?php else: ?> <?php echo e($r->getReplayUserInfo->username); ?> <?php endif; ?>
										</a>
										<?php if($r['replay_type'] == 1): ?> 回复:
										<a href="">
											<?php if($r->getReplayToUserInfo->nick_name != ''): ?> <?php echo e($r->getReplayToUserInfo->nick_name); ?> <?php else: ?> <?php echo e($r->getReplayToUserInfo->username); ?> <?php endif; ?>
										</a>
										<?php endif; ?>	
											<span class="fc999">
											时间
											</span>
									</div>
									<div class="fc666 b-5"><?php echo e($r['content']); ?></div>
									<div>
										<?php if(session('usersid') != $r['from_user_id']): ?>
										<a href="<?php echo e(url('index/question/replayReplay/' . $r['id'])); ?>">回复</a>
										<?php endif; ?>
									</div>
									<!-- reply_box -->
								</div>
								<div class="clear"></div>
							</li>
						</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
</div>
<?php echo $__env->make('index/layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>