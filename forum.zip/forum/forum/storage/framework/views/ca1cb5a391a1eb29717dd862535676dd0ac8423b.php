<?php echo $__env->make('index/layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
        KindEditor.ready(function(K) {
                window.editor = K.create('#editor_id');
        });

</script>
<div class='container'>


	<form id="replay_form" method="post" action="<?php echo e(url('index/question/doReplayRe/' . $replay['id'])); ?>">
		<table >
			<tr>
				<td></td>
				<td id='input_subject'>
				</td>
				<td></td>
			</tr>
		
			<tr>
				<td></td>
				<td>
      				<textarea id="editor_id" name="content" style="width:850px;height:300px;"></textarea>
				</td>
				<td></td>
			</tr>
		

			<tr>
				<td></td>
				<td>
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="questionId" value="<?php echo e($replay['question_id']); ?>">
					<input type="hidden" name="toUsersId" value="<?php echo e($replay['from_user_id']); ?>">
					<input type="hidden" name="fromUsersId" value="<?php echo e(session('usersid')); ?>">
					<input type="hidden" name="commentId" value="<?php echo e($replay['comment_id']); ?>">
					<a href="<?php echo e(url('index/question/replayDetail/' . $replay['comment_id'])); ?>" class='btn btn-info' style='float:right; margin:10px;'>取消回复</a>
					<input type="submit" value="回复" class='btn btn-info' style='float:right; margin:10px;'/>
				</td>
				<td>
				</td>
			</tr>
			
		</table>
	</form>
	</div>
</div>
<?php echo $__env->make('index/layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>