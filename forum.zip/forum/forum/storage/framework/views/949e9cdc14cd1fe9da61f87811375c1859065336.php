<div class="top-div">
	<div class="container clearfix">

		<div class="span3 logo-div logo-img" style="margin-left: 0px;">
			<a href="/" title="医疗器械创新网"><img src="<?php echo e(asset('index/images')); ?>/logo.jpg" class="ie6png"
				style="display: block;height:80px;" /></a>
		</div>

		<div class="span11 pull-right top-ad"
			style="position: relative; _float: right; _height: 80px; _overflow: hidden;">

			<a href="javascript:;" class="pull-left" target="_blank"
				rel="nofollow"> <img alt="" src="<?php echo e(asset('index/images')); ?>/img1.jpg"
				style="width: 100%; display: block;" /></a> <a href="javascript:;"
				class="pull-left" style="display: none;" target="_blank"> <img
				alt="" src="images/img2.jpg" style="width: 100%; display: block;" /></a>


			<div class="slides-icon-ad slides-ad-point"
				style="position: absolute; right: 60px;">
				<a href="javascript:void(0);" class="icon-css-on ie6png">&nbsp;</a>
				<a href="javascript:void(0);" class="icon-css ie6png">&nbsp;</a>
			</div>

		</div>
	</div>
</div>