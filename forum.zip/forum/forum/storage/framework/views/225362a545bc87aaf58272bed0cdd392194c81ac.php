<?php echo $__env->make('index/layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="<?php echo e(asset('index/bootstrap_2/css')); ?>/bootstrap.min.css" rel="stylesheet">	

<div class='container'>
	<div id="comment_div" class="t-10 label-div border-all pr-20 pl-20" >
		<div class="txmd">     
		    <h4 class="mmh4">个人中心</h4>
		    <img src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($user['user_image']); ?>" id="user_image" alt="">
		    <span id="nick_name">
		    	<?php if($user['nick_name'] != ''): ?> <?php echo e($user['nick_name']); ?> <?php else: ?> <?php echo e($user['username']); ?> <?php endif; ?>
		    </span>
			<span id="signature"><?php echo e($user['signature']); ?></span>
		    <br><br>
		    <p id="sex">
		    	<?php if($user['sex'] == '1'): ?> 男 <?php else: ?> 女 <?php endif; ?>
		    </p>
		    <?php if(session('usersid') != $user['id']): ?>
		    <p id="concerns_it" data-url="<?php echo e(url('')); ?>" data-sex="<?php echo e($user['sex']); ?>">
		    	<?php if($concernedIt != ''): ?>
			    <a href="javascript:concerns_it(<?php echo e($user['id']); ?>)"><span id="concernsIt" class="concerns_ok">√已关注</span></a>
		    	<?php else: ?>
		    	<a href="javascript:concerns_it(<?php echo e($user['id']); ?>)"><span id="concernsIt" class="concerns_no">+关注<?php if($user['sex'] == '1'): ?>他<?php else: ?>她<?php endif; ?></span></a>
		    	<?php endif; ?>
		    </p>
		    <?php else: ?>
		    <p id="edit_userinfo"><a href="<?php echo e(url('index/users/userinfo/' . session('usersid'))); ?>">编辑个人资料</a></p>
		    <?php endif; ?>
		</div>
		<hr id="live_hr">
		
		<div id="two_live">
			<a href="" style="font-size: 17px; color: black; margin-left: 15px;">贴吧动态</a>
			<a href="<?php echo e(url('index/users/center',['id'=>$user->id])); ?>" >话题动态</a>
		</div>
		
		<hr style="margin: 0;">
		<div>
      		<ul class="nav nav-tabs">
      			<li class="active"><a data-toggle="tab" href="#live">我的关注</a></li>
      			<li><a data-toggle="tab" href="#answer">我的帖子</a></li>
      			<li><a data-toggle="tab" href="#question">我的回帖</a></li>
      			<li><a data-toggle="tab" href="#collection">我的收藏</a></li>
      		</ul>
      		<div class="tab-content">
      			<div class="tab-pane fade in active" id="live">
            		<div class="live">
            		
        				<a href="<?php echo e(url('index/question/container/')); ?>"><p class="topic_name">我的关注</p></a>
        				<div class="content">
        				

        				
        				
        				
        				<ul class='n_img clearfix'>
               
        				<?php $__currentLoopData = $ftype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       					<li class="Mycare" style='margin:0px;' id='Mycare<?php echo e($value1->ftype_id); ?>' display:block;>
        					 <a href='<?php echo e(url("index/forum/postbar",["id"=>$value1->id])); ?>'>
                      <img src="<?php echo e(asset('index/TypeImg/'.$value1->getftypeimg($value1->ftype_id))); ?>"  alt="" style='width:60px; height:60px;'>
                  </a>
        					 <a href='<?php echo e(url("index/forum/postbar",["id"=>$value1->id])); ?>'>
                    <font style='color:red; margin:0px; margin-top:50px;'><?php echo e($value1->getTypeName($value1->ftype_id)); ?></font>
                  </a>
        					<span style='font-size: 5px'>关注人数:<?php echo e($value1->getFtypeCare($value1->ftype_id)); ?></span>
        					<span><img src='<?php echo e(asset("index/images/qx.png")); ?>' style='width:20px;height:20px;' title='取消关注' onclick='javascript:carenum(<?php echo e($value1->ftype_id); ?>);'><a href='javascript:carenum(<?php echo e($value1->ftype_id); ?>);' style='font-size:3px '>取消关注</a></span>
        					
        					</li>
        					
        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        				<ul>	
                <script>
                function carenum(id){
                     var path = $('#self_path').val();
                      $.ajax({
                        url:path+"/index/careforum/carenum/"+id,
                        success:function(data){ 
                          if(data == 3){
                            $('#Mycare'+id).toggle();
                          }
                          if(data == 0){
                            window.alert('操作失败');
                            }
                          if(data == 2){
                            window.alert('请登录在进行操作');
                          }
                        }
                      })
                }

                </script>
        				</div>
        			</div>
      			</div>

      			<div class="tab-pane fade" id="answer">
      				<?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="live<?php echo e($value2->id); ?>" display:block;>
        				<a href="<?php echo e(url('index/forum/container',['id'=>$value2->id])); ?>"><p class="topic_name"><?php echo e($value2->subject); ?></p></a>
        				<div>
        		<?php if($value2->getForumImg($value2->id)): ?>
							<img src="<?php echo e(asset('index/forumimg')); ?>/<?php echo e($value2->getForumImg($value2->id)[0]['image']); ?>" alt="" style="width: 40px; height: 40px; float:left;">
						<?php else: ?>
							<img src="<?php echo e(asset('index/TypeImg')); ?>/<?php echo e($value2->image); ?>" alt="" style="width: 40px; height: 40px; float:left;">
						<?php endif; ?>
							<div class="users">
								<a href="">作者:<?php echo e($value2->getUsersid($value2->user_id)); ?></a>
								<p></p>
							</div>
							<p class="goodItQuestion">发表时间<?php echo e(date('Y-m-d H:i:s',$value2->ctime)); ?></p>
        				</div>

        				<div class="content">
        					<p class="comment"><?php echo e(str_limit(strip_tags($value2->content),'60','...')); ?></p>
        				</div>

        				<div class="set">
        					<span><a href="<?php echo e(url('index/forum/container',['id'=>$value2->id])); ?>"><img src="<?php echo e(asset('index/images')); ?>/comment.png" alt=""><?php echo e($value2->commentnum); ?></a></span>
        					<span><a href="<?php echo e(url('index/forum/container',['id'=>$value2->id])); ?>"><img src="<?php echo e(asset('index/images')); ?>/collection.png" alt="" title=""><?php echo e($value2->like); ?></a></span>
					     		<span><a href="javascript:deleteforum(<?php echo e($value2->id); ?>);"><img src="<?php echo e(asset('index/images')); ?>/delete.png" alt="" title="删除"></a></span>
					     		<script>
									function deleteforum(id){
										var path = $('#self_path').val();
										$.ajax({
											type:'GET',
											url:path+'/index/forum/delete/'+id,
											data:{'id':id},
											success:function(data){
												if(data == 1){
													$('.live'+id).toggle();	
													}else{
													window.alert('系统繁忙 稍后重试');
														}
											}
											});
										}	
					     		</script>
        				</div>
        			</div>
              <HR/>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        			<hr>
        			
      			</div>












            <div class="tab-pane fade" id="collection">
              <?php $__currentLoopData = $likeforum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="live<?php echo e($like->forum_id); ?>" display:block;>
                <a href="<?php echo e(url('index/forum/container',['id'=>$like->forum_id])); ?>"><p class="topic_name"><?php echo e($like->getforumInfo($like->forum_id)['subject']); ?></p></a>
                <div>
                
             
            
             <?php if($like->getImgForum($like->forum_id)): ?>
              <img src="<?php echo e(asset('index/forumimg')); ?>/<?php echo e($like->getImgForum($like->forum_id)); ?>" alt="" style="width: 40px; height: 40px; float:left;">
            <?php else: ?>
              <img src="<?php echo e(asset('index/forumimg/default.png')); ?>" alt="" style="width: 40px; height: 40px; float:left;">
            <?php endif; ?>
            
              <div class="users">
                <a href="">作者:<?php echo e($user->getUserInfo($like->getforumInfo($like->forum_id)['user_id'])['nick_name']); ?></a>
                <p></p>
              </div>
              <p class="goodItQuestion">发表时间:<?php echo e(date('Y-m-d H:i:s',$like->getforumInfo($like->forum_id)['ctime'])); ?></p>
                </div>

                <div class="content">
                  <p class="comment"><?php echo e(str_limit(strip_tags($like->getforumInfo($like->forum_id)['content'])),'50','...'); ?></p>
                </div>

                <div class="set">
                  <span><a href="<?php echo e(url('index/forum/container',['id'=>$like->forum_id])); ?>"><img src="<?php echo e(asset('index/images')); ?>/comment.png" alt="">(<?php echo e($like->getforumInfo($like->forum_id)['commentnum']); ?>)</a></span>
                  <span><a href="<?php echo e(url('index/forum/container',['id'=>$like->forum_id])); ?>"><img src="<?php echo e(asset('index/images')); ?>/collection.png" alt="" title="">(<?php echo e($like->getforumInfo($like->forum_id)['like']); ?>)</a></span>
                  <span><a href="javascript:carequxiao(<?php echo e($like->forum_id); ?>);"><img src="<?php echo e(asset('index/images')); ?>/delete.png" alt="" title="取消收藏"></a></span>
           <script>
                  function carequxiao($id){
                    var path = $('#self_path').val();
                    $.ajax({
                      url:path+"/index/forum/like/"+$id,
                      success:function(data){
                        if(data == 0){
                            $('.live'+$id).toggle();
                        }else{
                          window.alert('系统繁忙 稍后重试');
                        }
                        
                      }
                    })
                  }
           </script>
                </div>
              </div>
            
              <hr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>































            <div class="tab-pane fade" id="question">
<?php $__currentLoopData = $forumid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
          <div class="live" display:block;>
                <a href="<?php echo e(url('index/forum/container',['id'=>$forum1])); ?>"><p class="topic_name"><?php echo e($commentmodel->getForumName($forum1)['subject']); ?></p></a>
                <div>
                
           <?php if($commentmodel->getForumIMG1($forum1)): ?>
              <img src="<?php echo e(asset('index/forumimg')); ?>/<?php echo e($commentmodel->getForumIMG1($forum1)[0]['image']); ?>" alt="" style="width: 40px; height: 40px; float:left;">
            <?php else: ?>
              <img src="<?php echo e(asset('index/forumimg/default.png')); ?>" alt="" style="width: 40px; height: 40px; float:left;">
            <?php endif; ?>    
            
              <div class="users">
                <a href="">作者:<?php echo e($commentmodel->getUsersid($commentmodel->getForumName($forum1)['user_id'])); ?></a>
                <p></p>
              </div>
              <p class="goodItQuestion">我最后评论时间:<?php echo e(date('Y-m-d H:i:s',$commentmodel->getEndCommentUser1($forum1,$user->id)['ctime'])); ?></p>
                </div>

                <div class="content">
                  <p class="comment">我最后评论内容:<?php echo $commentmodel->getEndCommentUser1($forum1,$user->id)['content']; ?></p>
                  <a href='JavaScript:togglecomment(<?php echo e($forum1); ?>);'>查看所有回复内容</a>
                </div>
                <div >
                    <ul id='total_comment<?php echo e($forum1); ?>' style='display:none;'>
                       
                        
                             
                             <table>

                              <?php $__currentLoopData = $commentmodel->getEndCommentUser2($forum1,$user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                              <tr id='commentforum_<?php echo e($a["id"]); ?>'>

                              <td>
                               内容:<font style='color:red;'><?php echo $a['content']; ?></font>
                              </td>
                              <td>
                                <?php echo e(date('m月d日 H:i:s')); ?>                                  
                              </td>  
                               <td>
                                   <a href="javascript:delete_comment(<?php echo e($a['id']); ?>,<?php echo e($forum1); ?>);"><img src="<?php echo e(asset('index/images')); ?>/delete.png" style='width:10px;' alt="" title="删除评论"></a>
                               </td>  

                               </tr>
                              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                               </table>  
                            
                        
                       
                    
                    </ul>
                    
                </div>
                <div class="set" >
                  <span><a href="<?php echo e(url('index/forum/container')); ?>"><img src="<?php echo e(asset('index/images')); ?>/comment.png" alt="">(<?php echo e($commentmodel->getForumName($forum1)['commentnum']); ?>)</a></span>
                  <span><a href="<?php echo e(url('index/forum/container')); ?>"><img src="<?php echo e(asset('index/images')); ?>/collection.png" alt="" title="">(<?php echo e($commentmodel->getForumName($forum1)['like']); ?>)</a></span>
                  
     
         
                </div>
              </div>
            
              <hr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>









      		</div>
		</div>
		
	</div>
</div>
<script src="<?php echo e(asset('bootstrap_2/js')); ?>/jquery-1.12.4.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('bootstrap_2/js')); ?>/bootstrap.min.js"></script>


<?php echo $__env->make('index/layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>