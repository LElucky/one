<?php echo $__env->make('index/layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="<?php echo e(asset('index/bootstrap_2/css')); ?>/bootstrap.min.css" rel="stylesheet">	

<div class='container'>
	<div id="comment_div" class="t-10 label-div border-all pr-20 pl-20" >
		<div class="txmd">     
		    <h4 class="mmh4">个人中心</h4>
		    <img src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($user['user_image']); ?>" id="user_image" alt="">
		    <span id="nick_name">
		    	<?php if($user['nick_name'] != ''): ?> <?php echo e($user['nick_name']); ?> <?php else: ?> <?php echo e($user['username']); ?> <?php endif; ?>
		    </span>
			<span id="signature"><?php echo e($user['signature']); ?></span>
		    <br><br>
		    <p id="sex">
		    	<?php if($user['sex'] == '1'): ?> 男 <?php else: ?> 女 <?php endif; ?>
		    </p>
		    <?php if(session('usersid') != $user['id']): ?>
		    <p id="concerns_it" data-url="<?php echo e(url('')); ?>" data-sex="<?php echo e($user['sex']); ?>">
		    	<?php if($concernedIt != ''): ?>
			    <a href="javascript:concerns_it(<?php echo e($user['id']); ?>)"><span id="concernsIt" class="concerns_ok">√已关注</span></a>
		    	<?php else: ?>
		    	<a href="javascript:concerns_it(<?php echo e($user['id']); ?>)"><span id="concernsIt" class="concerns_no">+关注<?php if($user['sex'] == '1'): ?>他<?php else: ?>她<?php endif; ?></span></a>
		    	<?php endif; ?>
		    </p>
		    <?php else: ?>
		    <p id="edit_userinfo"><a href="<?php echo e(url('index/users/userinfo/' . session('usersid'))); ?>">编辑个人资料</a></p>
		    <?php endif; ?>
		</div>
		<hr id="live_hr">
		
		<div id="two_live">
			<a href="<?php echo e(url('index/users/forumcenter',['id'=>$user->id])); ?>">贴吧动态</a>
			<a href="" style="font-size: 17px; color: black; margin-left: 15px;">话题动态</a>
		</div>
		
		<hr style="margin: 0;">
		<div>
      		<ul class="nav nav-tabs">
      			<li class="active"><a data-toggle="tab" href="#live">我的动态</a></li>
      			<li><a data-toggle="tab" href="#answer">回答(<?php echo e($total_comments); ?>)</a></li>
      			<li><a data-toggle="tab" href="#question">提问(<?php echo e($total_question); ?>)</a></li>
      			<li><a data-toggle="tab" href="#collection">收藏(<?php echo e($total_collection); ?>)</a></li>
      			<li><a data-toggle="tab" href="#i_concerns">我关注的人(<?php echo e($total_i_concerned); ?>)</a></li>
      			<li><a data-toggle="tab" href="#concerns_me">关注我的人(<?php echo e($total_concerned_me); ?>)</a></li>
      		</ul>
      		<div class="tab-content">
      			<div class="tab-pane fade in active" id="live">
            		<div class="live">
        				<a href="<?php echo e(url('index/question/container/')); ?>"><p class="topic_name">我的动态</p></a>
        				<div class="content">
        					<p class="ctime">什么歌</p>
        				</div>
        			</div>
      			</div>

      			<div class="tab-pane fade" id="answer">
      				<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="live">
        				<a href="<?php echo e(url('index/question/container/' . $com['question_id'])); ?>"><p class="topic_name"><?php echo e($com->getQuestionInfo->qname); ?></p></a>
        				<div>
							<img src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($user['user_image']); ?>" alt="" style="width: 40px; height: 40px; float: left;">
							<div class="users">
								<a href=""><?php echo e($com->getCommentUserInfo->nick_name); ?></a>
								<p><?php echo e($com->getCommentUserInfo->signature); ?></p>
							</div>
							<p class="goodItQuestion">(<?php echo e($com->getTotalGood->good); ?>)人赞同了该回答</p>
        				</div>

        				<div class="content">
        					<p class="comment"><?php echo e($com['comment']); ?></p>
        				</div>

        				<div class="set">
        					<span>(<?php echo e($com->getTotalGood->good); ?>)<a href=""><img src="<?php echo e(asset('index/images')); ?>/good.png" alt=""></a></span>
        					<span>(<?php echo e($com->getTotalGood->bad); ?>)<a href=""><img src="<?php echo e(asset('index/images')); ?>/bad.png" alt=""></a></span>
        					<span>(<?php echo e($com->getTotalComments()); ?>)<img src="<?php echo e(asset('index/images')); ?>/comment.png" alt=""></a></span>
        					<span><a href=""><img src="<?php echo e(asset('index/images')); ?>/collection.png" alt="" title="收藏该回答"></a></span>
					     		<span><a href=""><img src="<?php echo e(asset('index/images')); ?>/delete.png" alt="" title="删除"></a></span>
        				</div>
        			</div>
        			<hr>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</div>

      			<div class="tab-pane fade" id="question">
		      	 		<?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            			<div class="live">
            				<a href="<?php echo e(url('index/question/container/' . $q['id'])); ?>"><p class="topic_name"><?php echo e($q['qname']); ?></p></a>
            				<div class="content">
            					<p class="ctime">2018-02-01 (<?php echo e($q->getTotalComments()); ?>)个回答 (<?php echo e($q->getTotalCollection()); ?>)个关注</p>
            				</div>
            			</div>
            			<hr>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</div>

      			<div class="tab-pane fade" id="collection">
      				<?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="live">
            				<a href="<?php echo e(url('index/question/container/' . $col['question_id'])); ?>"><p class="topic_name"><?php echo e($col->getCollectionInfo->qname); ?></p></a>
            				<div class="content">
            					<p class="ctime"><?php echo e(date('Y-m-d',$col->getCollectionInfo->ctime)); ?>&nbsp;·&nbsp; (<?php echo e($col->getTotalComments()); ?>)个评论 (<?php echo e($col->getTotalCollection()); ?>)人收藏</p>
            				</div>
        			</div>
        			<hr>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</div>

				<div class="tab-pane fade" id="i_concerns">
      				<?php $__currentLoopData = $i_concerned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i_con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="concerns_me">
						<img src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($i_con->getIConcerned->user_image); ?>" alt="">
						<div class="concerns_user">
	        				<a href="<?php echo e(url('index/users/center/' . $i_con['concerned_user_id'])); ?>"><p class=""><?php echo e($i_con->getIConcerned->nick_name); ?></p></a>
	        				<p><?php echo e($i_con->getIConcerned->signature); ?></p>
	        				<p>(<?php echo e($i_con->getAnswerIConcerned()); ?>)回答 · (<?php echo e($i_con->getConcernedIConcerned()); ?>)关注者</p>
        				</div>
        			</div>
        			<hr>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</div>

      			<div class="tab-pane fade" id="concerns_me">
      				<?php $__currentLoopData = $concerned_me; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con_me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="concerns_me">
						<img src="<?php echo e(asset('index/users_image')); ?>/<?php echo e($con_me->getConcernedMe->user_image); ?>" alt="">
						<div class="concerns_user">
	        				<a href="<?php echo e(url('index/users/center/' . $con_me['user_id'])); ?>"><p class=""><?php echo e($con_me->getConcernedMe->nick_name); ?></p></a>
	        				<p><?php echo e($con_me->getConcernedMe->signature); ?></p>
	        				<p>(<?php echo e($con_me->getAnswerConcernedMe()); ?>)回答 · (<?php echo e($con_me->getConcernedConcernedMe()); ?>)关注者</p>
        				</div>
        			</div>
        			<hr>
        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			</div>
      		</div>
		</div>
		
	</div>
</div>
<script src="<?php echo e(asset('bootstrap_2/js')); ?>/jquery-1.12.4.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('bootstrap_2/js')); ?>/bootstrap.min.js"></script>


<?php echo $__env->make('index/layouts/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>