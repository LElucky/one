<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bad extends Model
{
    protected $table = 'bad';
    public $timestamps = false;
}
