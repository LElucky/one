<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ausers extends Model
{
    protected $table = 'ausers';
    public $timestamps = false;
}
