﻿@include('index/layouts/header')
<!DOCTYPE html><!--STATUS OK--><html><head><meta name="keywords" content="贴吧,百度贴吧,论坛,兴趣,社区,BBS"/><meta name="description" content="百度贴吧——全球最大的中文社区。贴吧的使命是让志同道合的人相聚。不论是大众话题还是小众话题，都能精准地聚集大批同好网友，展示自我风采，结交知音，搭建别具特色的“兴趣主题“互动平台。贴吧目录涵盖游戏、地区、文学、动漫、娱乐明星、生活、体育、电脑数码等方方面面，是全球最大的中文交流平台，它为人们提供一个表达和交流思想的自由网络空间，并以此汇集志同道合的网友。" /><meta charset="UTF-8"><meta name="baidu-site-verification" content="BeXfvLldS5" /><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><meta name="baidu-site-verification" content="jpBCrwX689" /><link rel="search" type="application/opensearchdescription+xml" href="/tb/cms/content-search.xml" title="百度贴吧" /><title>百度贴吧——全球最大的中文社区</title><script type="text/javascript">void function(t,e,n,a,o,i,r){t.alogObjectName=o,t[o]=t[o]||function(){(t[o].q=t[o].q||[]).push(arguments)},t[o].l=t[o].l||+new Date,a="https:"===t.location.protocol?"https://fex.bdstatic.com"+a:"http://fex.bdstatic.com"+a;var c=!0;if(t.alogObjectConfig&&t.alogObjectConfig.sample){var s=Math.random();t.alogObjectConfig.rand=s,s>t.alogObjectConfig.sample&&(c=!1)}c&&(i=e.createElement(n),i.async=!0,i.src=a+"?v="+~(new Date/864e5)+~(new Date/864e5),r=e.getElementsByTagName(n)[0],r.parentNode.insertBefore(i,r))}(window,document,"script","/hunter/alog/alog.min.js","alog"),void function(){function t(){}window.PDC={mark:function(t,e){alog("speed.set",t,e||+new Date),alog.fire&&alog.fire("mark")},init:function(t){alog("speed.set","options",t)},view_start:t,tti:t,page_ready:t}}(),void function(t){var e=!1;t.onerror=function(t,n,a,o){var i=!0;return!n&&/^script error/i.test(t)&&(e?i=!1:e=!0),i&&alog("exception.send","exception",{msg:t,js:n,ln:a,col:o}),!1},alog("exception.on","catch",function(t){alog("exception.send","exception",{msg:t.msg,js:t.path,ln:t.ln,method:t.method,flag:"catch"})})}(window),window.xssfw=function(t){function e(t,e){if(!(10<++p)){var n={type:"INLINE",path:t,code:e.substr(0,400),len:e.length};alog("xss.send","xss",n),d.push(n),c()}}function n(t,e){if(t&&0!=e){var a=t.tagName;if("BODY"!=a){t.id&&(a+="#"+t.id);var o=t.className;return o&&(a+="."+o.split(" ")[0]),(o=n(t.parentNode,e-1))?o+" "+a:a}}}function a(t){for(var e=g.length-1;e>=0;e--){var n=g[e];if(t>n.b)return n}}function o(t){for(var e=f.length-1;e>=0;e--){var n=f[e];if(n.b.test(t))return n}}function i(t,i){function r(s){var l=s._k;if(l||(l=s._k=++u),l=l<<8|i,!m[l]&&(m[l]=!0,1==s.nodeType)){var f;s[t]&&(f=s.getAttribute(t))&&(l=a(f.length)||o(f)||{},l.a&&(s[t]=null),l.c&&e(n(s,5)+"["+t+"]",f)),c&&"A"==s.tagName&&"javascript:"==s.protocol&&(f=s.href.substr(11),l=a(f.length)||o(f)||{},l.a&&(s.href="javascript:void(0)"),l.c&&e(n(s,5)+"[href]",f)),r(s.parentNode)}}var c="onclick"==t;document.addEventListener(t.substr(2),function(t){r(t.target)},!0)}function r(t){var e=[];if(t)for(var n=t.length-1;n>=0;n--){var a=t[n],o=a.target;e.push({b:a.match,a:/D/.test(o),c:/W/.test(o)})}return e}function c(){if(s){for(var t=0;t<d.length;t++)s(d[t]);d=[]}}var s,l,f,g,p=0,m={},u=0,d=[],h={};return h.init=function(e){if(t.addEventListener&&!l){l=!0,alog("xss.create",{dv:5,postUrl:"https:"===document.location.protocol?"https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK/tb/pms/img/st.gif":"https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK/tb/pms/img/st.gif",page:"tb-xss"}),g=r(e["len-limit"]),f=r(e["key-limit"]),e=0;for(var n in document)/^on./i.test(n)&&i(n,e++)}},h.watch=function(t){s=t,c()},h}(this),xssfw.init({"len-limit":[{match:400,target:"Warn"}],"key-limit":[{match:/createElement/,target:"Warn"},{match:/fromCharCode|eval|getScript|xss/,target:"Warn,Deny"},{match:/alert\(|prompt/,target:"Warn"}]});</script><!--[if lt IE 9]><script>(function(){    var tags = ['header','footer','figure','figcaption','details','summary','hgroup','nav','aside','article','section','mark','abbr','meter','output','progress','time','video','audio','canvas','dialog'];    for(var i=tags.length - 1;i>-1;i--){ document.createElement(tags[i]);}})();</script><![endif]--><link rel="shortcut icon" href="//tb1.bdstatic.com/tb/favicon.ico" />
<link rel="stylesheet" href="{{asset('index/forumstyle')}}/css/52a813f27e644b459fd8d5e126ad0261.css" />
<link rel="stylesheet" href="{{asset('index/forumstyle')}}/css/b623a355bbc24dfd9b3ce3844dacfb4c.css" />
<link rel="stylesheet" href="{{asset('index/forumstyle')}}/css/d9da5969fb1c4dc59b43bd998d146f13.css" />
<link rel="stylesheet" href="{{asset('index/forumstyle')}}/css/61cdc8c6e1434e0aaf3869b0b0d4ba41.css" />

	<div id="local_flash_cnt"></div>
	<div class="wrap1">
		<div class="wrap2">
			<script>
				PageData.tbs = "71ab9769204180f51517058050";
				PageData.is_iPad = 0;
				PageData.itbtbs = "a906665dd7a0c1c7";
				PageData.userTages = {};
			</script>
			<div class="page-container">
				<div class="search-sec">
					<div id="head" class="search_bright_index search_bright clearfix" style="">
						<div class="head_inner">
							<div class="search_top clearfix">
								<div class="search_nav j_search_nav" style="">
							
								</div>
							</div>
							<div class="search_main_wrap">
								<div class="search_main clearfix">
									<div class="search_form">
																			<img src='{{asset("index/images/logo.jpg")}}' style="width:70px; position:absolute; left:550px;">
									
										<form name="f1" class="clearfix j_search_form" action="/f" id="tb_header_search_form"><input class="search_ipt search_inp_border j_search_input tb_header_search_input" name="kw1" value="" type="text" autocomplete="off" size="42" tabindex="1" id="wd1" maxlength="100" x-webkit-grammar="builtin:search" x-webkit-speech="true" /><input autocomplete="off" type="hidden" name="kw" value="" id="wd2" /><span class="search_btn_wrap search_btn_enter_ba_wrap"><a rel="noopener" class="search_btn search_btn_enter_ba j_enter_ba" href="#" onclick="return false;" onmousedown="this.className+=' search_btn_down'" onmouseout="this.className=this.className.replace('search_btn_down','')">进入贴吧</a></span><span class="search_btn_wrap"><a rel="noopener" class="search_btn j_search_post" href="#" onclick="return false;" onmousedown="this.className+=' search_btn_down'" onmouseout="this.className=this.className.replace('search_btn_down','')">全吧搜索</a></span>
											
										</form>
										<p style="display:none;" class="switch_radios"><input type="radio" class="nowtb" name="tb" id="nowtb"><label for="nowtb">吧内搜索</label><input type="radio" class="searchtb" name="tb" id="searchtb"><label for="searchtb">搜贴</label><input type="radio" class="authortb" name="tb" id="authortb"><label for="authortb">搜人</label><input type="radio" class="jointb" checked="checked" name="tb" id="jointb"><label for="jointb">进吧</label><input type="radio" class="searchtag" name="tb" id="searchtag" style="display:none;"><label for="searchtag" style="display:none;">搜标签</label></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="main-sec clearfix">
					<div class="top-sec clearfix">
						<div id="rec_left" class="rec_left">
							<div class="carousel_wrap tbui_slideshow_container" id="carousel_wrap">
								<ul class="img_list tbui_slideshow_list">
									<li alog-group="img_list_21pic" alog-alias="img_list_21pic" class="img_list_3pic tbui_slideshow_slide" style="display: none;">
										<div class="ed5e06178b  clearfix">
											<a href="/link?client_type=pc_web&tbjump=lid%253D50339780_26931_13___0%2526url%253Dee86xyONfFgJPLFuHBjyAjixs9Qt5n_-r_LFR4JDT0no4ILJleDbCqUkhLaoTXgdSguARRNyIStc9kq3GWcQ2b6LRzOumlaYEnXysAVVbFkIKjV43zZbdzsUqQvE_38JancPHTyuxPTJXu_PxMlpStwXfE4Sb6H5CeSaHzadoZqi-r4OMebqVaFDGEjITe5tdStF_EgTAUHSm80mRXrHEVuJjbFA8a0g-9ZwN-AiGPZhXpjD0v13xfK4zzDmQV-JU2lGGZHl51LE0Rd1X4_tR5s3tYqLVMXy9aRw1Wnh3b5iL0wvVeNetyttIYW98nfwPnneXNOUKA7Rxfkap0Btcn39Adg9adcEz4uWyHaW0jOGCl6U4HKufsf8zVfr6F44Z_zpNjfveCZabuu4GGVZ2pEOOf2Q0M3vitKLPrExbgKFRMdteUd8OaXSJ4e0TbQIC9mFLOevuz7xH77iHZGgOZShK_5fw_yeNKoty-acL7RDcfrRCx6xHrmX5SOrcT5sy5FFxG_cgeixpub70SodLvkTUrqVYxGkH9b1eaqpNhXyKAae-BShDr_zn8zKeYfcbgmWD-S5IVupLLFvIeZwA3qvuZk33OJki3ELsL-styPvSQOPl3GbeuPk_hf26OiX0l3viV8lqunsHik21HGvYyrdVIQurTQgZccu4YbRjHfL-lMXzTAJutAUMu0jIKGIh5g-n54Nf6b_-dq2YiMuAd1ZHsrcyMSXJjZpRWBUGSW3Sxf_VlmO6Qc5Hgjuhf9VguCzntCr7rsKtxeSZx9qbISKVJFDO09jNKthd3TRQ9gY4uwtbgsI-aeQZgcYwr3JjRQiunMuLnFkHgkEi7NXGmMuFhR4xwqWcAJ5hUjKZ4SOrmCoPpMMYCmEqGsg-ZIjaiEra61ZGIT-JuzzOUdY6ZN-a9hE1Oxtknoxmk67uMiKSIPjCQqSk_ldV28oi7f-HyWL58lheOJwP10Y_DWCg5yhBzmIW01N2UFIQtxPZiGAfo0e5FBiyjgWuoYaLw-yhWWDTBvd45sBnGGmPbzyzAkUpzm74yeXlO5nV2F4q9ybQZVMS9fwPQEcFBsQOzCQwyadzWRYRZurnjidYCOBSDnUnIpEP4UOG5m18tVlKA9xXG5YmyLAAT-X8G33_GgNELJzxyvwwpZsB5pW9D9es7-gFpaHIwwHFGjoQL7BHUwY&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=26931" target="_blank" class="j_click_stats" data-locate="图片">
												<img src="{{asset('index/forumstyle/picture')}}//file_1516960007691.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片" />
												<div class="img_txt">
													<p class="img_title">文武贝钢琴演奏《等你下课》</p>
												</div>
											</a>
										</div>


<style>
    div.ed5e06178b {
        width:300px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.ed5e06178b .img_txt{
        width:300px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        
    }

</style><div class="carousel_promotion_replacement" data-index="1" style="width:187px;height:180px;">
  <a rel="noopener" href="https://tieba.baidu.com/f?ie=utf-8&kw=%E8%B4%B4%E5%90%A7%E5%A8%B1%E4%B9%90" target="_blank">
    <img src="{{asset('index/forumstyle/picture')}}//034117a81ce8afcd9bee4fcd73ee8561.png" alt="贴吧图片" title="贴吧图片" />
    <div class="img_txt">
            <p class="img_title">爱豆们等你来翻牌！</p>
        </div>
  </a>
</div> <div class="qa114a27ba  clearfix">
    <a href="/link?client_type=pc_web&tbjump=lid%253D50339780_26726_13___0%2526url%253D7b59UoJA-wbHcebnoAvs1uTzqNp8etXnLMaELO2H6zB_cAZ0rUTN_n4uGMNTZMaLsM_5aLudQs25mH-4fCogU8Uu6HpQp3m49Bg1lF1AG4N-H51EYKXwGvs32etGSZ7d9P7MOHFAonb94FOlER_Cri-K7n6PW4tvUiChWsCbNr2CHaCVeLVcu70fYNS7MVJLXIjLcG5Hjlljpzu6tAj2Vq5Zhhf5ut0_k4MNFbDtHMSiz8wQ0Fmyv75VkDg-qR0R6RUjY8Mkr08K6eZ2Eh5Q5mqmSztUv_PQIakjNdSlsbUvLS6N-4pBim1GZVN8fd-rruFSTOgtj4tfqnwPL_oU8qqgBZ7cdY_xoid-eicGA_Qpic1qKidIAmP9_3nXk6gLliQSfi0xYD2XkO_qb3surX81rCke5y5spusKDf_bxdfmtT-3fc1fNcCkvZlZjjigeuA3_Au45Tp3H1fx-a1ORcFSdnihzkZxNQOGD38WjEjttkE6St4QsjVG6yv5kPMjn8ozAqGytO1lNE41mZQVMMJJpZTL9kTt5-UUyu9viib1pZllE5pcgYb9AoN7d-DcYQ3JD5NMWFABec91X1SKiY9dafU1gwKhuBmsasPNIujCX1kd5X1k36yPbz42RxFk5boH_BKNe2eIsA2DpGTPKzPOLQD14oiRXvZcHxeOnxjXcVYGvkOA2ezqDT0vsRMx9RjdMEFFa-VEf9HmOSQKAsAmVtjbXXQSO9gcg19cR_ZSxFB5do5UIccTFjuUooMZ1zf0Ztm0Jixi1Gbml2nruP79dN_AqvY9R6w6VeLmH_adxjsWjffwIxzbI5ZBQB9uefyW9Usxsnm2BZ1fY_-muCbpa2myel6OQZb_oI2XsRxa0120QnJrZVgdOQK4ewDFpESKF1TilMNuoqLYZxxtCCsNXqQzc6iuf7QvCpXrx9ktsW2VY3YzpjFX186I2zxKduc17xuO2-uD7b8zmUIIJXreKBcUW5vp8HnCyINOtXiKrDTMTd8o-EderWdZHavQQ6_XbhEcTVU4wwbqU65IRzZWjSlwFduLXX84gqM20G7JDZtQMcRXuHrRfJCS8dTUikAUvo8aVDUzbfeG2ADQgcthyUj3ZmclYVNa4thZXrYDcnfPHELQYJmowP3aFHeJleTo-oD5SPBz9oOCFqkI78fIvTmv2zAMFTicTmK4uYc&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=26726" target="_blank" class="j_click_stats" data-locate="图片">
        <img src="{{asset('index/forumstyle/picture')}}//file_1516847668875.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片"/>
        <div class="img_txt">
            <p class="img_title">即将上映的科幻片</p>
        </div>
    </a>
</div>

<style>
    div.qa114a27ba {
        width:187px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.qa114a27ba .img_txt{
        width:187px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        
    }

</style></li><li alog-group="img_list_3pic" alog-alias="img_list_3pic" class="img_list_3pic tbui_slideshow_slide" style="display: none;">          <div class="c25cc604be  clearfix">
    <a href="/link?client_type=pc_web&tbjump=lid%253D50339780_26727_13___0%2526url%253D1bcdErQ_X3bxlp5tCoLYzgUiZWO4GWXS3gBKcZHtYtafngKHt1TJ49Tpq2WJivjsTK2bf7tcuVY9aRzujS9GvxJaYj6v6UYV2XhNeyPRFjqn96Vu3bzIVmZNouT9KW0boiUgAnQrJ9vMxOUl8iXGQvUF_2JVrCYN9nlwbBAVb6stwIA4RGQhcbocfFmerZi4h_SqSx8wUQmz6zccox2rOVsJeuiD1QjEXq84fSjvMXrkQimgt5x4XwUlqttJdG0ZZbdI5xJkcYoF4pgTkOc0lYMPbZvZk2nkGeZjizFVCksEtVMNkdgOrhR_Ts3Nz8T-53ht8pjVX4G1P1soE1SL88LdQawGKL_oRUYY8WGDoCV9-RvKz4LraeFA8itO6mTmOScQLiD2p2vzNz4WMkVs8llD577En1yGMDjscS7ZI-oj4O3vZHvJ4lzQwWzXqmyXcgXv-6VpBVAOtyPEIkEr3kcPJ5GfBvJ5Gzy-HrZk45dvrID0J7eZ7KwHxUUWkwD7Tg2DGdHwuJKXb6YGsf2c2TZZTUd9Q4pDVGdNf8A5ENeVN3i7ZgvH-Ex05-mLaH-PFEFOulPqTKyokU1WLquVQtLjfgt-UWmvGyoR17ETIQ20-qwe-zpWnmuumuRHA3zQcqcMK5yv9Z3yM9oBuA-vVfsqAO3GhwC6oYS_1MOM5SboAnfJ_ymf1zzWZQ-cyj6UruVNrYW1KPBf86Rjn3nKcPCWAM4uqTwBl9lGHuzTj__6K9QZqZmQlLVpI5QvgKclNVkQC59DZ2F3PdnbPkKoZS6CkOm61NkQ0RFeBLm7re7AFeVPUu8Gg9Tcv71CQH0RP7gC3Lz4T7dB959Ac3gTYdp3x3GvITiRk5vUvI9BccvTAY970qZ0BgasXEc-0XZjskAoTZ98TMRvyru9ivs54VfJnxMIIjANKpVBTX1LFp3ySjEQVKep9t7nwSoJTMK3DjbRbF9xILIDIHeLM55teMUSh3-ukPU9MNn7fJ6KOr73Ny9LrI5BZbcv_Jr3NGmVPt_exGuV9Ppm0oeU-x8sWrHzY7_lYtAIunX1XSWLRt3cQ5wbgbxdXXvVtsMoIg23o8QE-e35i30QXtvvLxHs-tgxYvpfXEa5Cs7kyU7Opg5rp_thQ6LQOYH3wRvgyARZaAf_YH1lT-ee8kwr3UYqPh-9hHh_hFbbHKxMsCRJzfc&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=26727" target="_blank" class="j_click_stats" data-locate="图片">
        <img src="{{asset('index/forumstyle/picture')}}//file_1516847746714.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片"/>
        <div class="img_txt">
            <p class="img_title">古装小仙女你心水谁？</p>
        </div>
    </a>
</div>

<style>
    div.c25cc604be {
        width:225px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.c25cc604be .img_txt{
        width:225px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        
    }

</style><div class="r1ee3c364e  clearfix">
    <a href="/link?client_type=pc_web&tbjump=lid%253D50339780_26934_13___0%2526url%253D710cQZ_z6x2PlEbwTrxqYQSR19hoyM9ZJmRYUmKMQhDMGYqU_VCdIzQjR8lO90CVZ8c6-yareh7dptT7vw5pHH5ZoodYvnZa-ZV4OnKfV6zprbGIlKgEiyYaUNHnYEbgJwksAlEMjMN5O_BZNsE_MfxtjgQeJ3kOCZopm4ErRuwy9vtfnMNHRLqYhT_gyzieIqM3KDbQBxDHEhl4NFHl9-pHq_MR3YnK33WIMSkVBz-ESkyoLNbtNocNquCCBf252mepef245eKTPA1LcB0-sJbdNDjSJ0r6jnN12vLXLrdAXbqrwA-lz0y_igVCv44DUtfBC--t4Deox6-LNBy-Tn5bbToNzggBDEgls7sarM-ZLmjE-6DB_DHJxeE7fKh6ipsPB1jPf303vuTiqhuukkZO_RFYX3BZjrLw1R7iSo3QGd2U0JsZtUVUrsmYumm8By_gQmfGTZ7ZOFRzqHgq_yJqRKDqCn56AckleHD2bnlYGvoGxVDpwD4Ajh55bXi-qlF6vTpzGWkuj6NJmZkdRB0Us7_n-kjTwP2PxwKFGtY65JEpG8snneEj9cQgO-CrRZeM2N_MUjkQivQzUFfN1g9cOS41OYkRprJH1LHXeOEC-2d9jhiHguXxNCkfDlHZcJnnUTlgatE1WR2XR2kPocu5y-zsXwzDtnCNE2hWmYJvLEVEMkiluiij9LpJ_sxp9_gqBE5wHlLAcJSTDdLWKghY6QsWzLGixUkTBcWHtuWObZYQ-rcaspefecH2ROQWkiGReH0bFR5dyYuHbNbGZiAaYuV4utnLTXfoFfOz5Oeu3cZD1txVfzIS4vYwnYu-4H9ucXtMfmnSFT4AJWIOxcVFjuFL8C172RT-wuPtfXtaEa3l2BgP8AFE-zL_R0ZJxl8cEv4WKe4EzpawWhDFnvdSOPZKGFYjqhTUX2z6N6JLSpNiOIt9ImKQJzNsTiD0vjs1tPDHQb2nBEmaMLf6YBxccPBTtNHEEgPQTvpBrwak8FBhQfA1anHbawPaHKIbyc0FbukBA2wq_yVdnd26aLWRQPAUVTrCsQkHjwlm_8jdqU6bEJkJhdlXTiTNdfszj4xid2Mrh-UaVDICQo8vAsFRkvFO26k4k8PsJQJdwXgvmKWh1W6ibezWobSuMYjbl5IayO6ieUOcRT2aySjaOIG1duAJAIpFFhT5EYjtEr0&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=26934" target="_blank" class="j_click_stats" data-locate="图片">
        <img src="{{asset('index/forumstyle/picture')}}//file_1516847870481.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片"/>
        <div class="img_txt">
            <p class="img_title">教你如何躺上王者</p>
        </div>
    </a>
</div>

<style>
    div.r1ee3c364e {
        width:225px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.r1ee3c364e .img_txt{
        width:225px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        
    }

</style><div class="lf4e9de26e  clearfix">
    <a href="/link?client_type=pc_web&tbjump=lid%253D50339780_26728_13___0%2526url%253D42308SK6IdP-odx3sUIxPS9hOqq49KDqme3zp6LqHhjVDHUgGlUVUkGj3bd_OUGDdUda1x23xDhDWF9hxgyD3SBqbbhXeTE5S6eGJVlPKTV_KLnm1PAcBYIYH-uCljU-UuFSvatMFf2O3MJCpDCTemvIX46qwuAKGS_Sj7zN4t6HM2Rwau1LLvSpG2GcWRVjnXFGsY_fQBdkCVmSffjpV0-R2snmI3wwJyfJ4At3JXTqnwFoPuLLNrX1qVki4SkU5P5miP53mamPydRFhjIKA_PEfItajIgYmQkIChO-_FxKAVtnHB9mIO4PvlK5XonIEkgWEM1Xba2fNMiPZoTqB37tFZR2hJYHIspdBRgwU9rVLIg5I34yEK4G4dKzrJFovs9cFc74RiBM8SP0bWlAif52bpQy4QrAxm0D7l4Cr76yQe_YORyGezdzbt9Kcg7Fghp2i2S4JIkFGTv3AXxhk5w_IKokG06foD9Qz23chEn8RpbUK9Kj0kmQ_96pTII13yss4WAOponizuuZEXx3-Dux1DKlG9Qofaj98j8DIsJW-1OTp8AfbDkN7VM2_bI8THv8drsRrNUyxhjXQFhO9HpYp1JuOmhlgbF_nJRESHMxNWXa2Z3QROVXL7KXe0xciOt_YHTLLd-X6admW18wI6gU5arf0-tDqOt2fy75QCa7xGSOd_MVvtmRki8sVslnAYKfk7FkfzFEXuO-md4SLkC_5ZQbY8AbQlvX70gsSYks1rBkLx6sDy_We3VwOuL-nU6CB7sy5vz2bJEvBMqEaCTvpzeAFIyvXYJHi71Iijnf_Dt2TinglgRvbJsRAwBQxUC9AIp655g2Gqsu5enjuCk0FJukQWZVGFAUdd_bQ1ljniUDO-uk_zFXj2kMkewYPaTtVetEmIWFwlIZdmbnEY7qZUz4w5A00oShsfnLcMY701qk8k226wX366_4q3Asp70Sy8JQWi7lsuBbnTC2AO3IsvXUtVLnRX3M551nfCfvNdyF0OHWtZ8Nk37Td83h3uU7B5mbnYNPlbRYO_E_ipEhOhsVxFToHFz_C98Lly2lKNHKlql4V3H-CcsbOiA5CGUOcOhHCdeU3AVES4lm_4G_tcR03zhP1wyPGPs_OhtkP_dsHUKDA1Lm3JHGyBIEAO2BCwXI9r1XVKDGZlW0FmZShXLjucjrwlzyuZQMlV4&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=26728" target="_blank" class="j_click_stats" data-locate="图片">
        <img src="{{asset('index/forumstyle/picture')}}//file_1516848012699.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片"/>
        <div class="img_txt">
            <p class="img_title">芭比的世界</p>
        </div>
    </a>
</div>

<style>
    div.lf4e9de26e {
        width:225px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.lf4e9de26e .img_txt{
        width:225px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        
    }

</style></li><li alog-group="img_list_1pic" alog-alias="img_list_1pic" class="img_list_1pic tbui_slideshow_slide" style="display: none;">          <div class="i255c6cbb3  clearfix">
    <a href="/link?client_type=pc_web&tbjump=lid%253D50339780_23709_13___0%2526url%253DdbcfNCS1jevouktfKzt7zwQU04XBPO64wVxXt0hR3wWcgbUD-7Zh83ztfsk80MBUY1NeTP1fxQ56CuA2tE0LUA-dqUbLmYLtoMqa5z3Apv_n8SSzA1Hfli8Ot2kyGhaQneA9scjwor195jQboxnIkCcZJ5iAHCzzl0pSu3HAV9zGf7mFD6vEHDHhH48Q--wFXLVI0vMP-b0hIf6GgtZiKO8YI4EcDZgI_ymatZxcGP1CXI8od6Q9eyA8xwIS_2bDGioxjTcfy20nJ_gogqjAi5iSlRdfWsDWcO2Ww4wQYvAbVWjntr3p14Kn_CeRItwTYqHcnYfSbauLNeHd_MqvggB98wI8rtdofhnKro65Oeduzw-T-Rx5exh6d4Opi-a4N0ZZPuLV4f0lBnhucw8NFBkNc0oltAc9VFg390unxJa9YWFm5SLVBcZ78yVdIoVV1O0zLIEup5g1nHXMryumo-wyWOlD_Fmy4ifBvw0bM5rJnOACuCvZCer0u4dVmpRMWy5XmAsQvhxRu9JlYDVLb2x9FkWzwhEzNsT1XWhcIyCJ6hKX1GP3fnglK0KDNE6lfOjj4TBbMNUPy1xdtX_ZbdIGgw2QOyqNaoXD0xEwQ6rV02RfExtWXehpN5ZKRUrZxo_NqPeIyk6jKRApAlEGktd6XZn2LP3ryeChY-OBtuKVNo3unMCG6WTgBqNkJZwZv8grmk1RtyhC58jXOaoJ2up-2oT48NPwvnxxNJ6Qny_gyqM0OWKFfa-dvySEkKOM0Q-aCADCR7Xk3tGAcEcjKrNsAbOtO8UdD0YAXogCt16WHJPR0oUx8M5d6j6MaClKROuXXLm87z_pMuy1Ec78u79FbeoBgvOjRNGMtlqLxohUqs7AfDSKDlT9Vj5hjhMEoAb6-FlFDdO9IQiav23PA6HGD8FARuHxvOiVd1BXh5Y01RMEPNrY1yGVfPcoeuW9WYscru0q1UohCoq-HG_LyAWi93iaxpLttrgrp3AETxUIEp6H93jLwyzgzDyckcsKebyStvoJ5xbkitDvtRJk-uAMOt6BwSYPHpwbyPe_9jvEXKrVu_O6DLd74y6ixM9POhFrbdNl9c1UiGULJ7VdhiL8LxGQQZzpJNneL0f6REVOkcp6KEjH7D5QHAk&task=&locate=&page=index&type=click&url=http%3A%2F%2Ftieba.baidu.com%2Findex.html%3F&refer=&fid=&fname=&uid=&uname=&is_new_user=&tid=&_t=1517058050&obj_id=23709" target="_blank" class="j_click_stats" data-locate="图片">
        <img src="{{asset('index/forumstyle/picture')}}//file_1516848095185.jpg" style="width: 100%;height: 100%;" alt="贴吧图片" title="贴吧图片"/>
        <div class="img_txt">
            <p class="img_title"></p>
        </div>
    </a>
</div>

<style>
    div.i255c6cbb3 {
        width:690px;
        height:180px;
        border: none;
        background: none;
        display: inline-block;
        position: relative;
        
    }

    div.i255c6cbb3 .img_txt{
        width:690px;
        height: 30px;
        border: none;
        background: rgba(0,0,0,0.5);
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
        display:none;
    }

</style></li><li alog-group="img_list_2pic" alog-alias="img_list_2pic" class="img_list_2pic tbui_slideshow_slide" style="display: none;">          <div class="carousel_promotion_replacement" data-index="7" style="width:280px;height:180px;">
  <a rel="noopener" href="https://tieba.baidu.com/f?kw=%E7%AB%9E%E6%8A%80%E6%B8%B8%E6%88%8F" target="_blank">
    <img src="{{asset('index/forumstyle/picture')}}//149ff66c960363c086b12f7022fea755.jpeg" alt="贴吧图片" title="贴吧图片" />
    <div class="img_txt">
            <p class="img_title">吧友们的电竞梦想聚集地</p>
        </div>
  </a>
</div> <div class="carousel_promotion_replacement" data-index="8" style="width:400px;height:180px;">
  <a rel="noopener" href="https://tieba.baidu.com/p/5328890637" target="_blank">
    <img src="{{asset('index/forumstyle/picture')}}//63653a5b814350d1c472fe864cdc8351.png" alt="贴吧图片" title="贴吧图片" />
    <div class="img_txt">
            <p class="img_title">游戏吧主VIP</p>
        </div>
  </a>
</div> </li></ul></div><div class="top_progress_bar"><span id="top_progress_prev" class="top_progress_prev"></span><ul id="img_page" class="img_page"><li>4</li></ul><span id="top_progress_next" class="top_progress_next">2</span></div></div><div class="index-forum-num-ten-millions"><div class="rec_right " id="rec_right"><div id="in_forum_num" class="num_list num_list02"><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span><span class="num_span"><i class="num_icon"></i></span>         <span class="num_span"><i class="num_icon"></i></span>         </div><a rel="noopener" href="#" class="btn_login"></a></div></div></div><div class="middle-sec clearfix"><div class="c417178a66  hide_style">
    <div class="iframe_wrapper clearfix">
    </div>
</div>

<style>
    div.c417178a66 {
        border: none;
        background: none;
        margin-bottom:10px;
    }
    
    div.hide_style {
        position: absolute;
        left: -9999px;
        z-index: -11;
    }

    div.c417178a66 .iframe_wrapper {
        width: 1000px;
        height: 90px;
    }

    div.c417178a66 .iframe_wrapper iframe {
        vertical-align: top;
        width: 100%;
        height: 100%;
    }
</style>
</div>










































<div class="content-sec clearfix">

    <div class="left-sec">
        <div class="left-cont-wraper" id="left-cont-wraper" class='sidebar'>
            <div class="aggregate_entrance_wrap">
                <h4 class="aggregate_entrance_title">贴吧精选专题</h4>
                <div>
                    <a rel="noopener" class="entrance_item" href="//tieba.baidu.com/t/f/?class=college">高校精选专题</a>
                </div>
            </div>
            <div class="u-f-t ufw-gap">
                <div class="title">贴吧分类</div>
                <div class="gap" style="width:125px"></div>
            </div>
            <div class="f-d-w" id="f-d-w" alog-alias="left-forums-category" alog-group="left-forums-category">
            
            
            
            
            
            @foreach($type as $ftype)
                <div class="" data-for="entertainment">
                    <div class="f-d-item-content">
                        <div class="title"><span class="typeicon entertainment"></span>
                            <a rel="noopener" title="{{$ftype['typename']}}" target="_blank" href="/f/index/forumpark?pcn=娱乐明星&pci=0&ct=1&rn=20&pn=1">{{$ftype['typename']}}</a>
                        </div>
                        <div class="directory-wraper">
                        
                        @foreach($typeson as $types)
							@if($types['fid'] == $ftype['id'])
                            <a rel="noopener" title="{{$types['typename']}}" target="_blank" href="{{url('index/forum/postbar/'.$types['id'])}}">
                            	
                            	
                            	{{$types['typename']}}
                            	
                            	
                            </a>
                            @endif
                        @endforeach    
                            <a rel="noopener" title="其他娱乐明星" target="_blank" href="/f/index/forumpark?cn=其他娱乐明星&ci=0&pcn=娱乐明星&pci=0&ct=1&rn=20&pn=1">其他{{$ftype['typename']}}</a>
                        </div>
                    </div>
                </div>
		@endforeach










                <div class="all-wraper">
                    <a rel="noopener" target="_blank" href="/f/index/forumclass" class="all"><span class="more-txt">查看全部</span></a>
                </div>
            </div>
        </div>
    </div>
    <div class="right-sec clearfix">
        <div class="r-top-sec">
            <div class="forum_recommend" alog-alias="forum_recommend">
                <div class="day_rcmd clearfix" id="day_rcmd" alog-group="day_rcmd"><span class="class_title">朵朵奇吧</span>
                
                @foreach($forum1 as $one)
                    <div class="rcmd_forum_list">
                        <div class="rcmd_forum clearfix">
                            <a rel="noopener" href="{{asset('index/forum/postbar/'.$one->id)}}" target="_blank" class="rcmd_forum_img"><img src="{{asset('index/TypeImg/'.$one->image)}}" style='width:95px;height:95px;' alt="" /></a>
                            <div class="rcmd_forum_desc">
                                <p class="rcmd_f_name">
                                    <a rel="noopener" href="{{asset('index/forum/postbar/'.$one->id)}}" target="_blank">{{$one->typename}}</a>
                                </p>
                                <p class="rcmd_f_reason">要发家，上贴吧！</p>
                                <p class="rcmd_f_num"><span class="rcmd_f_m_num">{{$one->carenum}}</span><span class="rcmd_f_p_num">{{$one->commentnum}}</span></p>
                            </div>
                        </div>
                    </div>
				@endforeach




                </div>
                <div class="good_rcmd" id="good_rcmd" alog-group="good_rcmd"><span class="class_title">一月新番</span>
                    <div class="good_forum_list clearfix">
                        <a rel="noopener" class="good_rcmd_left" id="good_rcmd_left" href="#" onclick="return false;"></a>
                        <div class="good_rcmd_center" id="good_rcmd_center">
                           




                            <ul id="gr_f_list" class="gr_f_list clearfix">

							@foreach($forum2 as $two)
                                <li class="clearfix">
                                    <a rel="noopener" class="good_forum clearfix" href="{{url('index/forum/postbar/'.$two->id)}}" target="_blank"><img src="{{asset('index/TypeImg/'.$two->image)}}" width="65" height="65" class="gf_pic" />
                                        <div class="gf_desc">
                                            <p class="gf_fname">{{$two->typename}}</p>
                                            <p class="gf_m_num">{{$two->carenum}}</p>
                                            <p class="gf_tag">贴吧动态</p>
                                        </div>
                                    </a>
                         	@endforeach



                                </li>
                            </ul>
                        </div>
                        <a rel="noopener" class="good_rcmd_right" id="good_rcmd_right" href="#" onclick="return false;"></a>
                    </div>
                </div>
            </div>
            <script>
                void
                function(e, t) {
                    for(var n = t.getElementsByTagName("img"), a = +new Date, i = [], o = function() {
                            this.removeEventListener && this.removeEventListener("load", o, !1), i.push({
                                img: this,
                                time: +new Date
                            })
                        }, s = 0; s < n.length; s++) ! function() {
                        var e = n[s];
                        e.addEventListener ? !e.complete && e.addEventListener("load", o, !1) : e.attachEvent && e.attachEvent("onreadystatechange", function() {
                            "complete" == e.readyState && o.call(e, o)
                        })
                    }();
                    alog("speed.set", {
                        fsItems: i,
                        fs: a
                    })
                }(window, document);
            </script>
        </div>
        <div class="r-left-sec">
            
            <div class="sub_nav_wrap clearfix" id="sub_nav_wrap" alog-alias="sub_nav_wrap" alog-group="sub_nav_wrap">
                <ul class="sub_nav_list">
                    <li style="margin-left:8px">
                        <a rel="noopener" href="#" tag_id="all" hot_index="0" id="j_remen_nav" class="nav_li nav_li_all cur">热门动态</a>
                    </li>
                    <li class="nav_hover" style=""></li>
                </ul>
            </div>
            <div id="like-tag-nav"><span></span>
                <a rel="noopener" href="#" class=""></a>
            </div>
            <div id="info-section"></div>
            <ul class="new_list" id="new_list" alog-alias="feedlist0" alog-group="feedlist0">



@foreach($hotforum as $forum)
                <li class="clearfix j_feed_li " fid="649787" data-forum-id="649787" data-thread-id="5501335377">
                    <div class="n_right">
                        <div>
                            <div class="title-tag-wraper">
                                <a rel="noopener" href="{{url('index/forum/postbar/'.$forum->type)}}" target="_blank" class="n_name feed-forum-link" title="{{$forum->getType($forum->type)}}" data-id="649787" data-type="forum">{{$forum->getType($forum->type)}}</a>
                            </div>
                            <div class="thread-name-wraper">
                                <a rel="noopener" href="{{url('index/forum/container',['id'=>$forum->id])}}" target="_blank" class="title feed-item-link" title="【美食】在上海一定要吃的50个地标性美食" data-id="5501335377" data-type="thread" data-locate="10">{{$forum->subject}}</a><span class="list-post-num"><em data-num="614">614</em><span class="list-triangle-border"></span><span class="list-triangle-body"></span></span>
                            </div>
                        </div>
                        <div class="n_txt"> </div>
                        <ul class="n_img clearfix" fname_u="%E5%A4%84%E5%AF%B9%E8%B1%A1" tid="5501335377">
                            <li><img title="点击查看大图" original="https://imgsa.baidu.com/forum/pic/item/cb1349540923dd54a8b0088cda09b3de9d824817.jpg" oriWidth="480" oriHeight="269" class="m_pic" src="{{asset('index/forumstyle/picture')}}//cb1349540923dd54a8b0088cda09b3de9d824817.jpg" width="150" height="105">
                                <div class="feed_highlight"></div>
                            </li>
                            <li><img title="点击查看大图" original="https://imgsa.baidu.com/forum/pic/item/49540923dd54564e6da64bddb8de9c82d0584f17.jpg" oriWidth="560" oriHeight="372" class="m_pic" src="{{asset('index/forumstyle/picture')}}//49540923dd54564e6da64bddb8de9c82d0584f17.jpg" width="150" height="105">
                                <div class="feed_highlight"></div>
                            </li>
                            <li><img title="点击查看大图" original="https://imgsa.baidu.com/forum/pic/item/0923dd54564e9258d1f6290a9782d158cdbf4e17.jpg" oriWidth="378" oriHeight="248" class="m_pic" src="{{asset('index/forumstyle/picture')}}//0923dd54564e9258d1f6290a9782d158cdbf4e17.jpg" width="150" height="105">
                                <div class="feed_highlight"></div>
                            </li>
                        </ul>
                       
                        <div class="n_reply">
                            <a rel="noopener" href="/home/main?un=%E9%80%86%E6%B5%81_%E8%80%8C%E4%B8%8B&fr=index" title="主题作者" target="_blank" class="post_author">{{$forum->user_id}}</a><span class="time">{{date('Y-m-d H:i:s')}}</span></div>
                    </div>
                </li>
@endforeach


                
            </ul>
            <div id="data_loading" class="data_loading"><img src="{{asset('index/forumstyle/picture')}}//loading.gif" width="22" height="22" /><span class="load_tip">.</span></div>
            <div id="btn_more" class="btn_more">
                <a href="#" style="text-decoration:none">更多精彩贴子</a>
            </div>
            <div id="data_error_bar" class="data_error_bar">
                <a href="#">数据加载失败，请点击重试</a>
            </div>
        </div>
        <div class="r-right-sec">
            <div class="right_wrap" id="right_wrap">
                <div>
                    <div class="app_download_box">
                        <div class="item_hd"><span class="title">扫二维码下载贴吧客户端</span></div>
                        <div class="clearfix app_download_wrap">
                            <div class="app_download_icon"></div>
                            <div class="app_download_info">下载贴吧APP<br />看高清直播、视频！</div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="nani_app_download_box">
                        <div class="item_hd"><span class="title">扫二维码下载Nani客户端</span></div>
                        <div class="clearfix app_download_wrap">
                            <div class="app_download_icon"><img src="{{asset('index/forumstyle/picture')}}//icon_202fd91.png" width="75" /></div>
                            <div class="app_download_info">Nani小视频<br />1遍不过瘾，越刷越开心</div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="topic_list_box">
                        <div class="item_hd"><span class="title">贴吧热议榜</span>
                            <a rel="noopener" class="verify_link" target="_blank" href="/hottopic/browse/topicList?res_type=1">查看榜单</a>
                        </div>
                        <ul class="topic_list_hot topic_list j_topic_toplist">
                        
                        <li>1111</li>
                        <li>1111</li>
                        <li>1111</li>
                        <li>1111</li>
                        <li>1111</li>
                        <li>1111</li>
                        <li>1111</li>
                        </ul>
                    </div>
                </div>
                <div> </div>





























<div class="item media_item" id="media_item" alog-alias="media_item">
  <div class="item_hd">
            <span class="title">贴吧娱乐</span>
            <a class="verify_link" target="_blank" href="Mailto:tiebayule@baidu.com">合作沟通</a>
  </div>
  <a class="media" href="http://tieba.baidu.com/p/5422824679"∠ target="_blank">
        <img src="{{asset('index/forumstyle/picture')}}//229f5351f0806d20d49089a086434cba.jpeg" height="90" width="220">
  </a>
  <ul class="media_list">
   <li>
          <a href="http://tieba.baidu.com/p/5393608033">盘点那些闪瞎眼的明星夫妇!</a>
      </li>
     <li>
          <a href="http://tieba.baidu.com/p/5384054520" target="_blank">同样是参加综艺，有人获赞有人被骂，差距在哪？</a>
      </li>
      
      <li>
          <a href="http://tieba.baidu.com/p/5316556774" target="_blank">回忆杀！昔日台湾偶像剧中的“男神们”今何在？</a>
      </li>
  
    
  </ul>
</div> 

<div alog-alias="notice_item" id="notice_item" class="item notice_item">
   <div class="item_hd">
      <span class="title">公告板</span>
  </div>
<a class="notice" href="https://tieba.baidu.com/p/5344825547">
      <img width="220" height="90" src="{{asset('index/forumstyle/picture')}}//公告板.jpg">
  </a>
  <ul alog-group="notice_list" class="notice_list">

       <li>
          <a href="http://tieba.baidu.com/p/5286428520">贴吧全面打击儿童色情信息</a>
        </li>
 
        <li>
          <a href="http://tieba.baidu.com/p/5267451989 ">贴吧积极配合网信办整改</a>
        </li>

    </ul>
</div>



<script>
var pv_img = new Image();
pv_img.src = "https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK/tb/img/pv.gif?fr=tb0_forum&st_mod=new_spage&st_type=pv_sum&_t="+(new Date().getTime());
</script></div></div></div></div><div class="bottom-bg"></div></div></div><div class="footer" alog-alias="footer">    <p alog-group="copy">©2018 Baidu<a  rel="noreferrer" href="//www.baidu.com/duty/">使用百度前必读</a><a  rel="noreferrer" href="https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK/tb/eula.html">贴吧协议</a><a  rel="noreferrer" href="//tieba.baidu.com/hermes/feedback">投诉反馈</a>信息网络传播视听节目许可证 0110516<a  rel="noreferrer" href="http://net.china.cn/chinese/index.htm" target="_blank"><img src="{{asset('index/forumstyle/picture')}}//net_0d27e51.png" width="20"></a><a  rel="noreferrer" href="http://www.bj.cyberpolice.cn/index.htm" target="_blank"><img title="首都网络110报警服务" src="{{asset('index/forumstyle/picture')}}//110_3adf20a.png" width="20"></a></p></div><script>window.alogObjectConfig = {  product: '14',     page: '14_3',        monkey_page: 'tieba-index', speed_page: '3',         speed: {            sample: '0.2'   },        monkey: {            sample: '0.01',      hid: '762'       },        exception: {                 sample: '0.1'   },    };</script>
 </div></div><script type="text/javascript">alog&&alog("speed.set","drt",+new Date);</script><script>PageUnitData={"search_input_tip":"\u8f93\u5165\u4f60\u611f\u5174\u8da3\u7684\u4e1c\u4e1c","dasense_messenger_whitelist":[["http:\/\/fedev.baidu.com"],["http:\/\/jiaoyu.baidu.com"],["http:\/\/caifu.baidu.com"],["http:\/\/jiankang.baidu.com"],["http:\/\/tieba.dre8.com"],["http:\/\/tdsp.nuomi.com"],["http:\/\/baiju.baidu.com"],["http:\/\/temai.baidu.com"],["http:\/\/tieba.baidu.com"],["http:\/\/zt.chuanke.com"],["http:\/\/window.sturgeon.mopaas.com"],["http:\/\/api.union.vip.com"],["http:\/\/api.dongqiudi.com"],["http:\/\/www.chuanke.com"],["http:\/\/dcp.kuaizitech.com\/"]],"like_tip_svip_black_list":"","icons_category":{"101":["\u5df4\u897f\u4e16\u754c\u676f"],"102":["\u661f\u5ea7\u5370\u8bb0"],"104":["\u8d34\u5427\u5370\u8bb0"]}};</script>
<script src="{{asset('index/forumstyle')}}/js/4b37361121ef4660a68a59a7e5b4732f.js"></script>
<script></script><script src="{{asset('index/forumstyle')}}/js/3bdbc8d4072e437eae933fa3c5add669.js"></script>
<script src="{{asset('index/forumstyle')}}/js/56a5272caa8f419fbf8678ef35276513.js"></script>
<script src="{{asset('index/forumstyle')}}/js/5c524637c49a44e4b5a513033f3b6b5c.js"></script>
<script src="{{asset('index/forumstyle')}}/js/1.js"></script>
<script>window.modDiscardTemplate={};</script>
</body>
</html>
<script> var _trace_page_logid = 0050339780; </script>